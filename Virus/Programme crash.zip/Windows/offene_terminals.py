import threading
import time
import ctypes

def endless_error_dialog():
    MB_OK          = 0x00000000
    MB_ICONERROR   = 0x00000010
    MB_SYSTEMMODAL = 0x00001000
    text  = "Ein schwerwiegender Systemfehler ist aufgetreten!\n"
    title = "Systemfehler"
    while True:
        ctypes.windll.user32.MessageBoxW(None, text, title, MB_OK | MB_ICONERROR | MB_SYSTEMMODAL)
        time.sleep(0.1)

def keep_terminal_open():
    # Diese Funktion blockiert das Schließen der Konsole
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    # 1) Begrüßung in der Konsole
    print("Hallo")
    time.sleep(2)
    print("Bitte warte einen Moment...")

    # 2) Warte 5 Sekunden
    time.sleep(5)

    # 3) Fehlertext in Rot in der Konsole
    print("\033[31mERROR 1\033[0m")
    time.sleep(2)
    print("\033[31mERROR 2\033[0m")
    time.sleep(2)
    print("\033[31mERROR 3\033[0m")
    time.sleep(2)
    print("\033[31mERROR 4\033[0m")
    time.sleep(2)
    print("\033[31mERROR 5\033[0m")
    time.sleep(2)
    print("\033[31mERROR 6\033[0m")
    time.sleep(2)
    print("\033[31mERROR 7\033[0m")
    time.sleep(2)
    print("\033[31mERROR 8\033[0m")
    time.sleep(2)

    # 4) Starte die unendlichen Fehler-Dialoge in einem Daemon-Thread
    t = threading.Thread(target=endless_error_dialog, daemon=True)
    t.start()

    # 5) Konsole offen halten, auch wenn der Nutzer versucht, das Fenster zu schließen
    keep_terminal_open()
